<?php
/**
 * Rendered on /groups/all?filter=discussion
 * Displays a list of discussions created within groups
 */

echo elgg_view('discussion/listing/all', [
	'container_type' => 'group',
]);
