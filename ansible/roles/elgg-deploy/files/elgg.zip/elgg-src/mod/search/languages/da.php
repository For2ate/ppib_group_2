<?php
/**
 * Translation file
 *
 * Note: don't change the return array to short notation because Transifex can't handle those during `tx push -s`
 */

return array(
	'search:results' => 'Resultater for %s',
	'search:more' => '+%s flere %s',

	'search:comment_on' => 'Kommentér "%s"',
	'search:unknown_entity' => 'Ukendt Entitets type',
);
