<?php
/**
 * Translation file
 *
 * Note: don't change the return array to short notation because Transifex can't handle those during `tx push -s`
 */

return array(
	'search:results' => 'Toraidhean luirg airson: "%s"',
	'search:more' => '+%s a bharrachd %s',

	'search:comment_on' => 'Fàg beachd air "%s"',
	'search:unknown_entity' => 'Eintiteis neo-aithnichte',
	'search:empty_query' => 'Cuir a-steach facal-luirg dligheach',
);
