<?php
/**
 * Translation file
 *
 * Note: don't change the return array to short notation because Transifex can't handle those during `tx push -s`
 */

return array(
	'search:results' => 'Wyniki dla %s',
	'search:more' => '+%s więcej %s',

	'search:comment_on' => 'Komentarze dotyczące "%s"',
	'search:unknown_entity' => 'Nieznany typ encji',
);
