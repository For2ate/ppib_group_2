<?php
/**
 * Translation file
 *
 * Note: don't change the return array to short notation because Transifex can't handle those during `tx push -s`
 */

return array(
	'search:results' => 'Resultados para %s',
	'search:more' => '+%s m&aacute;s %s',
	'search:unknown_entity' => 'Tipo de Entidad Desconocida',
);
