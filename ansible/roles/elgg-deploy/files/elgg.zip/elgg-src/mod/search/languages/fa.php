<?php
/**
 * Translation file
 *
 * Note: don't change the return array to short notation because Transifex can't handle those during `tx push -s`
 */

return array(
	'search:results' => 'نمایش نتایج برای %s',
	'search:more' => '+%s بیشتر %s',

	'search:comment_on' => 'نظر در "%s"',
	'search:unknown_entity' => 'نوع نهاد ناشناخته',
);
