<?php
/**
 * Translation file
 *
 * Note: don't change the return array to short notation because Transifex can't handle those during `tx push -s`
 */

return array(
	'search:results' => '%s 에 대한 결과',
	'search:more' => '+%s 더 %s',

	'search:comment_on' => '"%s" 에 대한 답글',
	'search:unknown_entity' => '알수없는 분류유형',
);
