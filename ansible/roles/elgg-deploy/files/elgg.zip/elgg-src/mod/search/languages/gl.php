<?php
/**
 * Translation file
 *
 * Note: don't change the return array to short notation because Transifex can't handle those during `tx push -s`
 */

return array(
	'search:results' => 'Resultados para %s',
	'search:more' => '+%s %s máis',

	'search:comment_on' => 'Comentario en «%s»',
	'search:unknown_entity' => 'Tipo de entidade descoñecido',
);
