<?php
/**
 * Translation file
 *
 * Note: don't change the return array to short notation because Transifex can't handle those during `tx push -s`
 */

return array(
	'members:label:online' => 'Air loidhne',
	'members:search' => 'Lorg sna buill',
	'members:total' => 'Buill gu h-iomlan: %s',
	'members:title:all' => 'Buill gu lèir',
	'members:title:newest' => 'Buill as ùire',
	'members:title:popular' => 'Buill as mòr-chòrdte',
	'members:title:online' => 'Buill air loidhne',
	'members:title:alpha' => 'Buill gu lèir',
	'members:list:popular:none' => 'Chan eil caraid aig buill sam bith.',
);
