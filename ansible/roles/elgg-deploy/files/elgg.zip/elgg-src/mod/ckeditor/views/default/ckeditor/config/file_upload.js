define(['elgg'], function(elgg) {
	return {
		simpleUpload: {
			// The URL that the images are uploaded to.
			uploadUrl: elgg.normalize_url('ckeditor/upload'),
		}
	}
});
