<?php
/**
 * Translation file
 *
 * Note: don't change the return array to short notation because Transifex can't handle those during `tx push -s`
 */

return array(
	'widgets:tagcloud:name' => 'وسم سحابي',
	'widgets:tagcloud:description' => 'وسم سحابي',
	'widgets:tagcloud:numtags' => 'إضهار عدد الوسوم السحابية',
	'tagcloud:site_cloud' => 'وسم سحابي للموقع',
	'tagcloud:allsitetags' => 'كل وسوم الموقع',
);
