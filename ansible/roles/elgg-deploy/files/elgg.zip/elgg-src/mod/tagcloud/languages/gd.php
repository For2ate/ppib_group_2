<?php
/**
 * Translation file
 *
 * Note: don't change the return array to short notation because Transifex can't handle those during `tx push -s`
 */

return array(
	'widgets:tagcloud:name' => 'Neul nan tagaichean',
	'widgets:tagcloud:description' => 'Neul nan tagaichean',
	'widgets:tagcloud:numtags' => 'Àireamh de tagaichean a chithear',
	'tagcloud:site_cloud' => 'Neul taga na làraich',
	'tagcloud:allsitetags' => 'Tagaichean gu lèir',
);
