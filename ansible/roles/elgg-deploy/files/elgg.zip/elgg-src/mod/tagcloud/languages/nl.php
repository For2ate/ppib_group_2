<?php
/**
 * Translation file
 *
 * Note: don't change the return array to short notation because Transifex can't handle those during `tx push -s`
 */

return array(
	'widgets:tagcloud:name' => 'Tag Cloud',
	'widgets:tagcloud:description' => 'Tag cloud',
	'widgets:tagcloud:numtags' => 'Aantal tags om weer te geven',
	'tagcloud:site_cloud' => 'Site tag-cloud',
	'tagcloud:allsitetags' => 'Alle site-tags',
);
