<?php
/**
 * Translation file
 *
 * Note: don't change the return array to short notation because Transifex can't handle those during `tx push -s`
 */

return array(
	'widgets:tagcloud:name' => 'Núvol d\'etiquetes',
	'widgets:tagcloud:description' => 'Núvol d\'etiquetes',
	'widgets:tagcloud:numtags' => 'Nombre d\'etiquetes a mostrar',
	'tagcloud:site_cloud' => 'Núvol d\'etiquetes',
	'tagcloud:allsitetags' => 'Totes les etiquetes',
);
