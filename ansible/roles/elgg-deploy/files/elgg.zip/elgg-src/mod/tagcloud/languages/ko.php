<?php
/**
 * Translation file
 *
 * Note: don't change the return array to short notation because Transifex can't handle those during `tx push -s`
 */

return array(
	'widgets:tagcloud:name' => '꼬리표 모음',
	'widgets:tagcloud:description' => '꼬리표 모음',
	'widgets:tagcloud:numtags' => '보여줄 꼬리표 수',
	'tagcloud:site_cloud' => '꼬리표 모음',
	'tagcloud:allsitetags' => '모든 꼬리표',
);
