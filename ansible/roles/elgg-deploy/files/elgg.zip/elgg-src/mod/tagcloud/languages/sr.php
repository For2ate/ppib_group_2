<?php
/**
 * Translation file
 *
 * Note: don't change the return array to short notation because Transifex can't handle those during `tx push -s`
 */

return array(
	'widgets:tagcloud:name' => 'Облак ознака',
	'widgets:tagcloud:description' => 'Облак ознака',
	'widgets:tagcloud:numtags' => 'Број ознака за приказ',
	'tagcloud:site_cloud' => 'Облак ознака целог сајта',
	'tagcloud:allsitetags' => 'Све ознаке сајта',
);
