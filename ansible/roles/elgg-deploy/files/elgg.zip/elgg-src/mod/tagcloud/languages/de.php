<?php
/**
 * Translation file
 *
 * Note: don't change the return array to short notation because Transifex can't handle those during `tx push -s`
 */

return array(
	'widgets:tagcloud:name' => 'Tagcloud',
	'widgets:tagcloud:description' => 'Tagcloud',
	'widgets:tagcloud:numtags' => 'Anzahl der anzuzeigenden Tags.',
	'tagcloud:site_cloud' => 'Tagcloud',
	'tagcloud:allsitetags' => 'Alle Tags der Seite',
);
