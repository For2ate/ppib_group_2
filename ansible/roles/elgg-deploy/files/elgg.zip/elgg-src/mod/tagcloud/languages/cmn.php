<?php
/**
 * Translation file
 *
 * Note: don't change the return array to short notation because Transifex can't handle those during `tx push -s`
 */

return array(
	'widgets:tagcloud:name' => '標籤雲',
	'widgets:tagcloud:description' => '標籤雲',
	'widgets:tagcloud:numtags' => '要顯示的標籤數量',
	'tagcloud:site_cloud' => '站臺標籤雲',
	'tagcloud:allsitetags' => '全站標籤',
);
