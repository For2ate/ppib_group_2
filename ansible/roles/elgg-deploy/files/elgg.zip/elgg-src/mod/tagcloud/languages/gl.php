<?php
/**
 * Translation file
 *
 * Note: don't change the return array to short notation because Transifex can't handle those during `tx push -s`
 */

return array(
	'widgets:tagcloud:name' => 'Nube de etiquetas',
	'widgets:tagcloud:description' => 'Nube de etiquetas',
	'widgets:tagcloud:numtags' => 'Número de etiquetas para mostrar',
	'tagcloud:site_cloud' => 'Nube de etiquetas global',
	'tagcloud:allsitetags' => 'Etiquetas globais',
);
