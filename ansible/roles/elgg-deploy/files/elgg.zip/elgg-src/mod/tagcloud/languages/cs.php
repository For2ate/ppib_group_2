<?php
/**
 * Translation file
 *
 * Note: don't change the return array to short notation because Transifex can't handle those during `tx push -s`
 */

return array(
	'widgets:tagcloud:name' => 'Zásobník štítků',
	'widgets:tagcloud:description' => 'Zásobník štítků',
	'widgets:tagcloud:numtags' => 'Počet zobrazených štítků',
	'tagcloud:site_cloud' => 'Zásobník všech štítků',
	'tagcloud:allsitetags' => 'Všechny štítky',
);
