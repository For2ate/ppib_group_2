<?php
/**
 * Translation file
 *
 * Note: don't change the return array to short notation because Transifex can't handle those during `tx push -s`
 */

return array(
	'widgets:tagcloud:name' => 'Nuage de Tags',
	'widgets:tagcloud:description' => 'Nuage de tags',
	'widgets:tagcloud:numtags' => 'Nombre de tags à afficher',
	'tagcloud:site_cloud' => 'Nuage de tags du site',
	'tagcloud:allsitetags' => 'Tous les tags du site',
);
