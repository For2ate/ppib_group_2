<?php
/**
 * Translation file
 *
 * Note: don't change the return array to short notation because Transifex can't handle those during `tx push -s`
 */

return array(
	'widgets:tagcloud:name' => 'Облако тегов',
	'widgets:tagcloud:description' => 'Облако тегов',
	'widgets:tagcloud:numtags' => 'Количество тегов для отображения',
	'tagcloud:site_cloud' => 'Облако тегов сайта',
	'tagcloud:allsitetags' => 'Все теги сайта',
);
