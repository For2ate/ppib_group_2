<?php
/**
 * Translation file
 *
 * Note: don't change the return array to short notation because Transifex can't handle those during `tx push -s`
 */

return array(
	'widgets:tagcloud:name' => 'Nuvola di tag',
	'widgets:tagcloud:description' => 'Nuvola di tag',
	'widgets:tagcloud:numtags' => 'Numero di tag da mostrare',
	'tagcloud:site_cloud' => 'Nuvola di tag del sito',
	'tagcloud:allsitetags' => 'Tutte i tag del sito',
);
