<?php
/**
 * Translation file
 *
 * Note: don't change the return array to short notation because Transifex can't handle those during `tx push -s`
 */

return array(
	'widgets:tagcloud:name' => 'タグクラウド',
	'widgets:tagcloud:description' => 'タグクラウド',
	'widgets:tagcloud:numtags' => 'タグの表示数',
	'tagcloud:site_cloud' => 'タグクラウド',
	'tagcloud:allsitetags' => '全タグ',
);
