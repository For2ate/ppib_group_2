<?php
/**
 * Translation file
 *
 * Note: don't change the return array to short notation because Transifex can't handle those during `tx push -s`
 */

return array(
	'widgets:tagcloud:name' => 'Tagipilvi',
	'widgets:tagcloud:description' => 'Tagipilvi',
	'widgets:tagcloud:numtags' => 'Näytettävien kohteiden määrä',
	'tagcloud:site_cloud' => 'Tagipilvi',
	'tagcloud:allsitetags' => 'Kaikki sivuston tagit',
);
