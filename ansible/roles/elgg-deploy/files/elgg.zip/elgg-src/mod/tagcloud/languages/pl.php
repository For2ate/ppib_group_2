<?php
/**
 * Translation file
 *
 * Note: don't change the return array to short notation because Transifex can't handle those during `tx push -s`
 */

return array(
	'widgets:tagcloud:name' => 'Chmura tagów',
	'widgets:tagcloud:description' => 'Chmura tagów',
	'widgets:tagcloud:numtags' => 'Ilość wyświetlanych tagów',
	'tagcloud:site_cloud' => 'Chmura tagów strony',
	'tagcloud:allsitetags' => 'Wszystkie tagi',
);
