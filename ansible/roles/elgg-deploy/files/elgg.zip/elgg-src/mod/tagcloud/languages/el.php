<?php
/**
 * Translation file
 *
 * Note: don't change the return array to short notation because Transifex can't handle those during `tx push -s`
 */

return array(
	'widgets:tagcloud:name' => 'Σύννεφο Ετικετών',
	'widgets:tagcloud:description' => 'Σύννεφο ετικετών',
	'widgets:tagcloud:numtags' => 'Αριθμός ετικετών για προβολή',
	'tagcloud:site_cloud' => 'Σύννεφο Ετικετών Ιστότοπου',
	'tagcloud:allsitetags' => 'Όλες οι ετικέτες',
);
