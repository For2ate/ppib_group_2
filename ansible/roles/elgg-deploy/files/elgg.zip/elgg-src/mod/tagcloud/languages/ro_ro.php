<?php
/**
 * Translation file
 *
 * Note: don't change the return array to short notation because Transifex can't handle those during `tx push -s`
 */

return array(
	'widgets:tagcloud:name' => 'Nor de Etichete',
	'widgets:tagcloud:description' => 'Nor de etichete',
	'widgets:tagcloud:numtags' => 'Numărul de etichete de afișat',
	'tagcloud:site_cloud' => 'Norul de Etichete al Site-ului',
	'tagcloud:allsitetags' => 'Toate etichetele site-ului',
);
