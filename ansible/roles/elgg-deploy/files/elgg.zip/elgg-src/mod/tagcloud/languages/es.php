<?php
/**
 * Translation file
 *
 * Note: don't change the return array to short notation because Transifex can't handle those during `tx push -s`
 */

return array(
	'widgets:tagcloud:name' => 'Nube de etiquetas',
	'widgets:tagcloud:description' => 'Nube de etiquetas',
	'widgets:tagcloud:numtags' => 'N&uacute;mero de etiquetas a mostrar',
	'tagcloud:site_cloud' => 'Nube de Tags del Sitio',
	'tagcloud:allsitetags' => 'Tags de todo el sitio',
);
