<?php
/**
 * Translation file
 *
 * Note: don't change the return array to short notation because Transifex can't handle those during `tx push -s`
 */

return array(
	'widgets:tagcloud:name' => '标签云',
	'widgets:tagcloud:description' => '标签云',
	'widgets:tagcloud:numtags' => '显示的标签数量',
	'tagcloud:site_cloud' => '全站标签云',
	'tagcloud:allsitetags' => '全站标签',
);
